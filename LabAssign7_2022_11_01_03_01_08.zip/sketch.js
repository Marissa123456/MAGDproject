var x = [];
function setup() {
  createCanvas(400, 400);
  noStroke();
  for (var i = 0; i < 3000; i ++){
    x[i] = random(-1000, 600);
  }
}

function draw() {
  background(118, 188, 235)
  fill(64, 209, 66);
  rect(0, 350, 400, 200);
  fill(145, 70, 71);
  rect(0, 50, 40, 300);
  arc(60, 350, 80, 80, PI, TWO_PI)
  rect(0, 310.65, 70, 30)
  arc(60, 100, 70, 70, 5.03, 2.20)
  arc(60, 160, 70, 70, 2.51, 5.20)
  fill(250, 162, 202)
  ellipse(30, 60, 90, 90, 10)
  ellipse(50, 110, 40, 40, 10)
  ellipse(90, 100, 70, 70, 10)
  ellipse(30, 30, 100, 100, 10)
  ellipse(130, 20, 150, 150, 10)
  ellipse(200, 50, 30, 30, 10)
  ellipse(175, 75, 50, 50, 10)
  ellipse(150, 100, 50, 50, 10)
  fill(0, 0, 0);
  ellipse(mouseX,mouseY, 10, 10) 
  //the above code is for a little bug, I originally had other ideas but couldn't figure out how to code them.
  for (var i = 0; i < x.length; i++){
    x[i] += 0.5;
    var y = i * 0.4;
    fill(239, 136, 184);
    arc(x[i], y, 20, 20, 2.51, 4.08)
  }
}